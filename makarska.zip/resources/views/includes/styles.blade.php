
    <link type="text/css" rel="stylesheet" href="{{ asset('/css/reset.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ asset('/css/plugins.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ asset('/css/style.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ asset('/css/color.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ asset('/css/app.css') }}">
