<?php
return [
    'Results For' => 'Ergebnisse für',
    
];