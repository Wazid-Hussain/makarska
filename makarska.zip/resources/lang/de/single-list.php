<?php
return [
    'Top' => 'Oben',
    'Gallery' => 'Galerie',
    'Details' => 'Einzelheiten',
    'Reviews' => 'Bewertungen',
    'Listing' => 'Auflistung',
    'Photos' => 'Photos',
    'About' => 'Über',
    'Amenities' => 'Ausstattung',
    'Add Revies & Rate iteam' => 'Artikel bewerten und bewerten',
    'Your rating for this listing :' => 'Ihre Bewertung für dieses Angebot:',
    'Your Name' => 'Dein Name',
    'Email Address' => 'E-Mail-Addresse',
    'Your Review' => 'Deine Bewertung',
    'Submit Review' => 'Bewertung abschicken'
    

];