<?php
return [
    'Home' => 'Home',
    'Accommodation' => 'Unterkünfte',
    'About us' => 'Über uns',
    'Contact' => 'Contact',
    'J Projects' => 'J Projects'
];