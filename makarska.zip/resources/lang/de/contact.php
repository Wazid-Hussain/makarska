<?php
return [
    'Our Contacts' => 'Unsere Kontakte',
    'Adress' => 'Ein Kleid',
    'Contact' => 'Kontakt',
    'Details' => 'Einzelheiten',
    'Home' => 'Heim',
    'Our Location'  => 'Unsere Standort',
    'Get In Touch'  => 'In Kontakt kommen',
    'Send'   =>  'Senden',
    'Join our online community' => 'Treten Sie unserer Online-Community bei',
    'Grow your marketing and be happy with your online business' => 'Steigern Sie Ihr Marketing und seien Sie mit Ihrem Online-Geschäft zufrieden',
    'Sign Up' => 'Anmeldung',
];