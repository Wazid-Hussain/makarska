<?php
return [
    'Accommodation type' => 'Unterkunftsart',
    'Check In' => 'Check In',
    'Check Out' => 'Check Out',
    'GUESTS' => 'GÄSTE',
    'Holiday home' => 'Ferienhaus',
    'Date'  => 'Datum',
    'Number of people'  => 'Personenanzahl',
    'No fixed travel period in mind yet? No problem!'   =>  'Noch kein festen Reisezeitraum vor Augen? Kein Problem!',
    'I\'m flexible' =>  'Ich bin Flexibel',
    'Listing' => 'Auflistung',
];