<?php
return [
    'About Us' => 'Über uns',
    'Phone' => 'Telefon',
    'Our Last News' => 'Unsere letzten Neuigkeiten ',
    'Our Instagram' => 'Unser Instagram',
    'Home' => 'Heim',
    'Listing'  => 'Auflistung',
    'Contacts'  => 'Kontakte',
    'All rights reserved.'   =>  'Alle Rechte vorbehalten.',
    'Subscribe' => 'Abonnieren',
];