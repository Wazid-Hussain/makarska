<?php
return [
    'About Us' => 'About Us',
    'Phone' => 'Phone',
    'Our Last News' => 'Our Last News',
    'Our Instagram' => 'Our Instagram',
    'Home' => 'Home',
    'Listing'  => 'Listing',
    'Contacts'  => 'Contacts',
    'All rights reserved.'   =>  'All rights reserved.',
    'Subscribe' => 'Subscribe',
];