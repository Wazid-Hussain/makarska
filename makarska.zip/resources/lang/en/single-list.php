<?php
return [
    'Top' => 'Top',
    'Gallery' => 'Gallery',
    'Details' => 'Details',
    'Reviews' => 'Reviews',
    'Listing' => 'Listing',
    'Photos' => 'Photos',
    'About' => 'About',
    'Amenities' => 'Amenities',
    'Add Revies & Rate iteam' => 'Add Revies & Rate iteam',
    'Your rating for this listing :' => 'Your rating for this listing :',
    'Your Name' => 'Your Name',
    'Email Address' => 'Email Address',
    'Your Review' => 'Your Review',
    'Your Review' => 'Your Review'
    

];