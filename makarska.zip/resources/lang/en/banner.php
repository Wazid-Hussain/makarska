<?php
return [
    'Accommodation type' => 'Accommodation type',
    'Check In' => 'Check In',
    'Check Out' => 'Check Out',
    'GUESTS' => 'GUESTS',
    'Holiday Home' => 'Holiday home',
    'Date'  => 'Date',
    'Number of people'  => 'Number of people',
    'No fixed travel period in mind yet? No problem!'   =>  'No fixed travel period in mind yet? No problem!',
    'I\'m flexible' =>  'I\'m flexible',
    'Listing' => 'Listing',
];