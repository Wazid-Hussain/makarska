<?php
return [
    'Home' => 'Home',
    'Accommodation' => 'Accommodation',
    'About us' => 'About us',
    'Contact' => 'Contact',
    'J Projects' => 'J Projects'
];